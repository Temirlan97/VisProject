Visualization
Prof. Michael Sedlmair
Done by:
	Temirlan Ulugbek uulu
	Zhao Liu

To see this webpage, place it in appropriate directory (e.g. in Ubuntu it's /var/www/html/) and 
run the local apache server or similar. Then go to "localhost" on your browser.

